<div class="vlaCalendar<?=($_POST['style'] ? ' '.$_POST['style'] : '')?>">
	<span class="indication">
		<div class="arrowRight"></div>
		<div class="arrowLeft"></div>
		<span class="label">&nbsp;</span>
	</span>
	<div class="container">
		<div class="loaderB"></div>
		<div class="loaderA">
<?php include "month.php"; ?>

		</div>
	</div>
</div>
