<?php
	$wdays_labels	= array("Mo", "Tu", "We", "Th", "Fr", "Sa", "Su");
	$month_labels	= array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
	$month_s_labels	= array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
?>